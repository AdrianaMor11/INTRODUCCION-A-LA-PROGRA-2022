﻿CONSOLE.WRITELINE("ADRIANA MORALES 1057021");
Console.WriteLine("Cuantos alumnos hay en la primer seccion:");
int n = Convert.ToInt32(Console.ReadLine());
int[] seccionA = new int[n];
Console.WriteLine("Cuantos alumnos hay en la segunda seccion:");
n = Convert.ToInt32(Console.ReadLine());
int[] seccionB = new int[n];

Console.WriteLine("seccion 1");
for (int i = 0; i < seccionA.Length; i++)
{
    Console.WriteLine($"{i + 1} Ingrese nota:");
    seccionA[i] = Convert.ToInt32(Console.ReadLine());
}

Console.WriteLine("seccion 2");
for (int i = 0; i < seccionB.Length; i++)
{
    Console.WriteLine($"{i + 1} Ingrese nota:");
    seccionB[i] = Convert.ToInt32(Console.ReadLine());
}

float p0 = 0f;
foreach (var item in seccionA)
{
    if (item > 60)
        p0++;
}

var porcentaje = p0 / seccionA.Length;
Console.WriteLine($"Porcentaje de aprobados Seccion 1: {porcentaje:p}");
Console.WriteLine($"Porcentaje de reprobados Seccion 1: {1 - porcentaje:p}");
float p1 = 0f;
foreach (var item in seccionB)
{
    if (item > 60)
        p1++;
}
porcentaje = p1 / seccionA.Length;
Console.WriteLine($"Porcentaje de aprobados Seccion 2: {porcentaje:p}");
Console.WriteLine($"Porcentaje de reprobados Seccion 2: {1 - porcentaje:p}");

porcentaje = (p1 + p0) / (seccionA.Length + seccionB.Length);
Console.WriteLine($"Porcentaje de aprobados de ambas secciones: {porcentaje:p}");
Console.WriteLine($"Porcentaje de desaprobados de ambas secciones: {1 - porcentaje:p}");

var x1 = 0;
foreach (var item in seccionA)
{
    x1 += item;
}
var x2 = 0;
foreach (var item in seccionB)
{
    x2 += item;
}
Console.WriteLine($"Promedio Seccion 1: {x1 / seccionA.Length}");
Console.WriteLine($"Promedio Seccion 2: {x2 / seccionB.Length}");
Console.WriteLine($"Promedio Total: {(x1 + x2) / (seccionA.Length + seccionB.Length)}");
var s1 = 0;
var m1 = 0;
foreach (var item in seccionA)
{
    if (item > 90)
        s1++;
    if (item > 60 && item < 75)
        m1++;
}
var s2 = 0;
var m2 = 0;
foreach (var item in seccionB)
{
    if (item > 90)
        s2++;
    if (item > 60 && item < 75)
		m2++;
}
Console.WriteLine($"Estudiantes con notas mayores a 90 Seccion 1: {s1}");
Console.WriteLine($"Estudiantes con notas menoews a 75 Seccion 1: {m1}");
Console.WriteLine($"Estudiantes con notas mayores a 90 Seccion 2: {s2}");
Console.WriteLine($"Estudiantes con notas menoews a 75 Seccion 2: {m2}");
